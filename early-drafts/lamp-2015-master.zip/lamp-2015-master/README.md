lamar-puzzlehunt
================

Repository of assets related to the spring 2015 Lamar University puzzlehunt.

License
-------

https://creativecommons.org/licenses/by-sa/4.0/

To reuse, include something like the following:

> Material from "[LaMP Challenge](https://github.com/MaPPmath/lamp-2015)" by 
[Mathematical Puzzle Programs](http://mappmath.org) 
is used  under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/).
